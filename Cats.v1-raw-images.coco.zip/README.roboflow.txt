
Cats - v1 raw-images
==============================

This dataset was exported via roboflow.ai on March 30, 2022 at 3:56 PM GMT

It includes 1159 images.
Cats are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


